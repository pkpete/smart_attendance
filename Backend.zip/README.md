# smart_attendance
graduation project
