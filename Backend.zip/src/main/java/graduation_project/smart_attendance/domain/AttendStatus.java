package graduation_project.smart_attendance.domain;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public enum AttendStatus {
    출석, 지각, 결석
}
