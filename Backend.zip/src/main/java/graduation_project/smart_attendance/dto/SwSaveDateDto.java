package graduation_project.smart_attendance.dto;

import lombok.Data;

@Data
public class SwSaveDateDto {
    private Long profID;
    private String course;
}
